#include "public.h"
#include "fileoper.h"
#include "runsever.h"

int main()
{
	load();
	run();
	save();
}
