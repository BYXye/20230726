#ifndef FILEOPER_H
#define FILEOPER_H

#include "public.h"

void load(void);

void save(void);

void load_manager(void);
void load_reader(void);
void load_book(void);

void save_manager(void);
void save_reader(void);
void save_book(void);
	
#endif
